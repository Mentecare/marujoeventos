# EventCore — Marujo Eventos

Versão preparada para produção permanente em **Vercel + Supabase**, sem dependência do Floot.

## Arquitetura

- **Vercel / Next.js**: frontend, PWA e rotas de servidor.
- **Supabase EventCore**: Auth, banco, RLS e dados operacionais.
- **Google Calendar API**: OAuth próprio do EventCore, com tokens criptografados no Supabase e nunca expostos no navegador.

O projeto usa o Supabase já existente:

- Project ref: `mzwlchgxkuqptiqyznqd`
- URL: `https://mzwlchgxkuqptiqyznqd.supabase.co`

A migration `eventcore_google_oauth_server_credentials` já foi aplicada no projeto real. A cópia SQL também está em `supabase/migrations` para versionamento.

## Variáveis da Vercel

Copie `.env.example` para a configuração do projeto na Vercel. **Não commite valores secretos.**

Obrigatórias:

```text
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
SUPABASE_SERVICE_ROLE_KEY
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
GOOGLE_OAUTH_STATE_SECRET
GOOGLE_TOKEN_ENCRYPTION_KEY
NEXT_PUBLIC_APP_URL
```

Gere os dois segredos próprios com algo equivalente a:

```bash
openssl rand -hex 32     # GOOGLE_OAUTH_STATE_SECRET
openssl rand -base64 32  # GOOGLE_TOKEN_ENCRYPTION_KEY
```

## Google Cloud

1. Crie/abra um projeto no Google Cloud.
2. Ative **Google Calendar API**.
3. Configure a tela de consentimento OAuth.
4. Crie um **OAuth Client ID > Web application**.
5. Adicione como Redirect URI:

```text
https://SEU-DOMINIO/api/google/callback
```

6. Coloque Client ID e Client Secret apenas nas Environment Variables da Vercel.

O EventCore pede somente `openid`, `email` e `https://www.googleapis.com/auth/calendar.events`.

## Deploy

### Recomendado: GitHub → Vercel

1. Crie ou use um repositório exclusivo do EventCore.
2. Envie o conteúdo desta pasta para a branch `main`.
3. Na Vercel, escolha **Add New > Project > Import Git Repository**.
4. Adicione as variáveis acima.
5. Faça o deploy.
6. Depois do primeiro domínio `*.vercel.app`, atualize `NEXT_PUBLIC_APP_URL` para o endereço final e repita o deploy.
7. Use esse mesmo endereço na Redirect URI do Google OAuth.

### Build local

```bash
npm install
npm run build
npm start
```

## Fluxos incluídos

- Login e primeiro acesso pelo Supabase Auth.
- Painel Admin/Coordenador.
- Clientes.
- Profissionais/freelancers.
- Eventos.
- Necessidades de equipe por função.
- Escala confirmada/reserva/convidado.
- Área do freelancer.
- Check-in e check-out com geolocalização pontual.
- Financeiro e registro de pagamentos.
- PWA instalável.
- Google Calendar com criação/atualização idempotente por `google_event_id`.

## Segurança

- `SUPABASE_SERVICE_ROLE_KEY` só é usado no servidor Next.js.
- Refresh tokens do Google são criptografados com AES-256-GCM antes de ir para o banco.
- `google_oauth_connections` tem RLS habilitado e nenhum grant para `anon` ou `authenticated`.
- O navegador continua usando apenas a publishable key do Supabase.
- O service worker não intercepta Supabase nem rotas `/api/`.

## Pendências de infraestrutura

O código está pronto para Vercel, mas a automação desta sessão encontrou dois bloqueios externos:

1. A integração GitHub devolve `403 Resource not accessible by integration` ao gravar no repositório `Mentecare/marujoeventos`.
2. O conector Vercel lista `deploy_to_vercel`, mas a ação está indisponível no servidor conectado (`Tool deploy_to_vercel not found`).

Esses bloqueios são de permissão/conector, não do projeto.
